<?php
echo "Tên tôi là: $name, năm nay tôi $age tuổi";
echo "<br>xin chào ".$_SESSION['username'];
?>