<?php
echo "Tiêu đề: $khachhangs->DienThoai";
echo "\n";

?>