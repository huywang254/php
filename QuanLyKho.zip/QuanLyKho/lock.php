<h1 style="color: red;text-align: center">Tài khoản bị khóa vui lòng liên hệ với admin</h1>
<!--<a href="login.php" style="color: blue;text-align: center;text-decoration: none">Đăng nhập bằng tài khoản khác</a>-->
<a href="index.php?controller=trangchu&action=logout" style="display:block;color: blue;text-align: center;text-decoration: none">Đăng nhập bằng tài khoản khác</a>